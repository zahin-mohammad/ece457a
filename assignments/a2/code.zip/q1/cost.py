from easom import f


def cost(state):
    x, y = state
    return f((x, y))
