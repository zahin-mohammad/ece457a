Run `python3 main.py` to run simulated annealing on the easom function using a trignometric temperature schedule.
At the end of the program, information about q1 will be printed to the console and also a graph will be displayed.

NOTE: Before running this question or any other please install requirements using `pip3 install -r requirements.txt` from the `src` folder one level above.