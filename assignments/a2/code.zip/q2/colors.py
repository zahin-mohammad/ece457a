class colors:
    RED = "\033[1;31;40m"
    GREEN = "\033[1;32;40m"
    BLUE = "\033[1;34;40m"
    ENDC = "\033[0m"