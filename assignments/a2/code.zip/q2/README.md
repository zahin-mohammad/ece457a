Run `python3 game.py` to make an AI agent play against a Random Agent once. The game will be displayed live in the console.

Run `python3 game.py <N>` to make the AI agent play against the random agent `N` times and display the average `plays/rounds` results at the end.

NOTE: Before running this question or any other please install requirements using `pip3 install -r requirements.txt` from the `src` folder one level above.