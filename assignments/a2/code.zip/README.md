Please install requirements using `pip3 install -r requirements.txt` before running any question.
All questions can be found inside their corresponding subdirectory.
They all have their own README.md files describing how to run them.
