Run `python3 main.py` to run simulated annealing on the VRP using a trignometric temperature schedule.
At the end of the program, information about the run will be printed.

This program might take around 10 to 15 mins to run. We found that this gave best results.

NOTE: Before running this question or any other please install requirements using `pip3 install -r requirements.txt` from the `src` folder one level above.